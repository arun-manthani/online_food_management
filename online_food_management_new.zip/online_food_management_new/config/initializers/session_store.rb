# Be sure to restart your server when you modify this file.

OnlineFoodManagementNew::Application.config.session_store :cookie_store, key: '_online_food_management_new_session'
