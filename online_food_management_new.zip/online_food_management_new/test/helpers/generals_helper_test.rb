require 'test_helper'

class GeneralsHelperTest < ActionView::TestCase
end
