require 'test_helper'

class GeneralsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
