class CreateOrders < ActiveRecord::Migration
  def change
    create_table :orders do |t|
      t.string :name , :null => false, :default => ""
      t.integer :price , :null => false, :default => ""

      t.timestamps
    end
  end

  def down
    drop_table :orders
  end
end
