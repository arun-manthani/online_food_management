class AddUsernameContactAddressToUsers < ActiveRecord::Migration
  def change
    add_column :users, :username, :string
    add_column :users, :contact, :string
    add_column :users, :address, :string
  end
end
