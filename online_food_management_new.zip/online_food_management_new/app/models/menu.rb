class Menu < ActiveRecord::Base
end
