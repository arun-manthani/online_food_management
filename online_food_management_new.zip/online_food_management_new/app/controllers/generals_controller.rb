class GeneralsController < ApplicationController

  def index
  end
end
