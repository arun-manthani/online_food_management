class HomeController < ApplicationController
  
end
