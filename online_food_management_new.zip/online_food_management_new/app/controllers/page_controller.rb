class PageController < ApplicationController
  before_action :authenticate_user!, only: [:home, :about]
  def home
  end

  def about
  end
end
