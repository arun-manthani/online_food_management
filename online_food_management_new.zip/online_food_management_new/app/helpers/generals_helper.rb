module GeneralsHelper
end
